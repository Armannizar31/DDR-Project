﻿using QueryService.Models;

namespace QueryService.Queries.Interfaces
{
    public interface IStudentQuery
    {
    }
}
