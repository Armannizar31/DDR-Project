﻿using QueryService.Queries.Interfaces;
using QueryService.Models;
using CommonData;
using System.Net.Http.Headers;
using Microsoft.EntityFrameworkCore;

namespace QueryService.Queries.Handlers
{
    public class StudentQuery: IStudentQuery
    {
        private readonly AppDbContext _db;
        public StudentQuery(AppDbContext db)
        {
            _db = db;
        }
    }
}
