﻿using QueryService.Queries.Interfaces;
using QueryService.Models;
using CommonData;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace QueryService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private IStudentQuery _studentQuery;
        public StudentController(IStudentQuery studentQuery)
        {
            _studentQuery = studentQuery;
        }
    }
}
