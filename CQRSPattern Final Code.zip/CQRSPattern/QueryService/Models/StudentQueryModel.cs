﻿namespace QueryService.Models
{
    public class StudentQueryModel
    {
        public int studentId { get; set; }
        public string studentFname { get; set; }
        public string studentLname { get; set; }
        public int studentAge { get; set; }
        public string studentGender { get; set; }
        public string studentClass { get; set; }
    }
}
