﻿using QueryService.Queries.Interfaces;
using QueryService.Models;
using CommonData;
using System.Net.Http.Headers;
using Microsoft.EntityFrameworkCore;

namespace QueryService.Queries.Handlers
{
    public class StudentQuery: IStudentQuery
    {
        private readonly AppDbContext _db;
        public StudentQuery(AppDbContext db)
        {
            _db = db;
        }
        public async Task<List<StudentQueryModel>> GetStudentsAsync()
        {
            return await _db.Students
            .Select(i => new StudentQueryModel
            {
                studentId = i.studentId,
                studentFname = i.studentFname,
                studentLname = i.studentLname,
                studentAge = i.studentAge,
                studentGender = i.studentGender,
                studentClass = i.studentClass
            }).ToListAsync();
        }
        public async Task<StudentQueryModel> GetStudentAsync(int id)
        {
            var student = _db.Students.Find(id);
            if(student!=null)
            {
                return new StudentQueryModel
                {
                    studentId = student.studentId,
                    studentFname=student.studentFname,
                    studentLname=student.studentLname,
                    studentAge=student.studentAge,
                    studentGender=student.studentGender,
                    studentClass = student.studentClass
                };
            }
            return null;
        }
    }
}
