﻿using QueryService.Models;

namespace QueryService.Queries.Interfaces
{
    public interface IStudentQuery
    {
        Task<List<StudentQueryModel>> GetStudentsAsync();
        Task<StudentQueryModel> GetStudentAsync(int id);
    }
}
