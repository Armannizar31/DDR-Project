﻿using QueryService.Queries.Interfaces;
using QueryService.Models;
using CommonData;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace QueryService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private IStudentQuery _studentQuery;
        public StudentController(IStudentQuery studentQuery)
        {
            _studentQuery = studentQuery;
        }
        [HttpGet]
        public async Task<IActionResult> GetStudents()
        {
            try
            {
                var students = await _studentQuery.GetStudentsAsync();
                return StatusCode(StatusCodes.Status200OK, students);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
        [HttpGet("{id}")]
        public async Task<IActionResult> GetStudent(int id)
        {
            try
            {
                var student = await _studentQuery.GetStudentAsync(id);
                return StatusCode(StatusCodes.Status200OK, student);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError);
            }
        }
    }
}
